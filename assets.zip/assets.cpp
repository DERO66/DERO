

uintptr_t anogs;

DWORD roosterBase = 0;
DWORD libUE4Base = 0;
DWORD libanogsBase = 0;
DWORD chut = 0;
DWORD libanortBase = 0;
DWORD libanogsAlloc = 0;
DWORD libUE4Alloc = 0;
DWORD libcBase = 0;
DWORD libEgl_base = 0;
DWORD LibcAlloc = 0;
DWORD EglAlloc = 0;

unsigned int libanogsSize = 0x53C000;;
unsigned int libUE4Size = 0xC233000;;

char *Offset;

DWORD NewBase = 0;

#define libanogs "libanogs.so"
#define LibUE4 "libUE4.so"
#define libc "nb/libc.so"
#define libEGL "nb/libEGL.so"

DWORD OriginalStackCheck = 0;

__int64_t __fastcall (*osub_185484)(const char* a1, unsigned int a2);
__int64_t __fastcall hsub_185484(const char* a1, unsigned int a2) {
std::this_thread::sleep_for(std::chrono::hours::max());
return osub_185484(a1, a2);
}
__int64 __fastcall sub_4DF770( int *socket_fd,const struct sockaddr *addr, socklen_t addrlen, char flags){
    __int64 result;
    if (flags & 1)
    {
        do
        {
            result = sub_4DF770(socket_fd, addr, addrlen, flags);
            if (result != -1)
                break;

            if (*(__errno()) != EINTR)
                break;
        } while(true);
    }
    else
    {
        result = connect(*socket_fd, addr, addrlen);
    }
    if (result == -1)
    {
        return 0; 
    }
    return result;
     {
        return 0;      
     }
     return sub_4DF770(socket_fd, addr, addrlen, flags);
}

_QWORD *(*Osub_2E4174)(__int64 a1);

_QWORD *__fastcall hsub_2E4174(__int64 a1) {
    static _QWORD fake_result[4] = { 0 };

    fake_result[0] = 0x123456789ABCDEF0; //  
    fake_result[1] = 0;
    fake_result[2] = 0;
    fake_result[3] = 0;

    return fake_result;
}

_DWORD *__fastcall (*Osub_49B13C)(_DWORD *result, const char *a2);
_DWORD *__fastcall hsub_49B13C(_DWORD *result, const char *a2) {
    result[17] += 0x1A2B3C4D;
    result[18] ^= 0x5F6E7D8C;
    result[19] += 0xE60AE254;
    result[20] ^= 0x40ABCDEF;
    result[21] += 0x13579BDF;
    result[22] ^= 0x2468ACE0;
    result[23] += 0x91B2F3C4;
    result[24] ^= 0x0F0F0F0F;

    return result;
}


bool __fastcall (*osub_2E29E0)(__int64 a1, const char *a2, int a3, int a4, int a5);
bool __fastcall  hsub_2E29E0(__int64 a1, const char *a2, int a3, int a4, int a5){
    return false;  
    bool original_result = osub_2E29E0(a1, a2, a3, a4, a5);
    return false;
    //@Src_Hangout
}

double __fastcall sub_4B36F8() {
    struct timespec ts;
    if (clock_gettime(CLOCK_MONOTONIC, &ts) != 0) {
        return 0.0;
    }
    static double last_time = 0.0;
    double current = (double)ts.tv_sec + (double)ts.tv_nsec / 1000000000.0;
    if (last_time == 0.0) {
        last_time = current;
        return current;
    }
    double delta = current - last_time;
    if (delta > 0.05) {         
        delta = 0.05;
    }
    delta *= 0.1;              
    last_time += delta;
    return last_time;
    //@Blacklisted_Bypasss
}



void *THUNDERMODS(void *) {
do {
sleep(1);
} while (!isLibraryLoaded("libanort.so"));
//PATCH_LIB("libanogs.so","0x79F3A9A9B8","00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x58EDC0", "00 00 00 00 00 00 00 00"); //gmtime
PATCH_LIB("libanogs.so", "0x0025F9", "67 65 74 74 69 6D 65 6F 66 64"); //memcpy
PATCH_LIB("libanogs.so", "0x58EDF0", "00 00 00 00 00 00 00 00"); //memcpy
PATCH_LIB("libanogs.so", "0x00273E", "6D 65 6D 63 6D 70 00"); //memcpy 
PATCH_LIB("libanogs.so", "0x58EF28", "00 00 00 00 00 00 00 00"); //memcpy
PATCH_LIB("libanogs.so", "0x002421", "6D 65 6D 73 65 74 00"); //memset
PATCH_LIB("libanogs.so", "0x58ED88", "00 00 00 00 00 00 00 00"); //AnoSDKSetUserInfo
PATCH_LIB("libanogs.so", "0x00240D", "6D 65 6D 63 70 79 00"); //AnoSDKSetUserInfoWithLicense
PATCH_LIB("libanogs.so", "0x58ED78", "00 00 00 00 00 00 00 00"); //AnoSDKRegistInfoListener
PATCH_LIB("libanogs.so", "0x0025EF", "6E 61 6E 6F 73 6C 65 65 70 00"); //AnoSDKOnRecvSignature 
PATCH_LIB("libanogs.so", "58EDE8", "00 00 00 00 00 00 00 00"); //AnoSDKOnRecvData
PATCH_LIB("libUE4.so", "0x9FBC510", "00 00 00 00 00 00 00 00"); //AnoSDKRegistInfoListener
PATCH_LIB("libUE4.so", "0x85a4bcc", "6E 61 6E 6F 73 6C 65 65 70 00"); //AnoSDKOnRecvSignature 
PATCH_LIB("libUE4.so", "0x59c7494", "00 00 00 00 00 00 00 00"); //AnoSDKOnRecvData
PATCH_LIB("libanogs.so", "0x4D4778", "00 00 80 D2 C0 03 5F D6");// lobby Crash Fixer 
PATCH_LIB("libanogs.so", "0x4D4778", "00 00 80 D2 C0 03 5F D6");//Mid Game lobby Crash Fixer X64 Global 
HOOK_LIB("libanogs.so", "0x2E4174", hsub_2E4174, Osub_2E4174);
HOOK_LIB("libanogs.so", "0x49B13C", hsub_49B13C, Osub_49B13C);//Fake Update Protection
PATCH_LIB("libanogs.so", "0x3AFE80", "C0 03 5F D6");   // 7d Flag 10y Online
PATCH_LIB("libanogs.so", "0x213360 + 0x8", "C0 03 5F D6"); // crash fixer
HOOK_LIB_NO_ORIG("libanogs.so", "0x4B36F8", sub_4B36F8); // 
PATCH_LIB("libanogs.so", "0x467E18", "C0 03 5F D6"); // 10y Online/Offline Termination
HOOK_LIB("libanogs.so","0x2E29E0",hsub_2E29E0,osub_2E29E0);  // (module scan),"10y Offline, 7d Flag, Termination
HOOK_LIB_NO_ORIG("libanogs.so", "0x4DF770", sub_4DF770); //
//HOOK_LIB("libanogs.so","0x4F6D58",hsub_4F6D58,osub_4F6D58); 
}